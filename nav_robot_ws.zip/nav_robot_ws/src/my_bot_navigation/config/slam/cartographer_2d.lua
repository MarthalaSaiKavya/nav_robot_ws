-- ============================================================================
--  Google Cartographer, 2D, LiDAR + wheel odometry   (slam_method:=cartographer)
-- ============================================================================
--  Install:  sudo apt install ros-jazzy-cartographer-ros
--  Cartographer is the main alternative to slam_toolbox. Same idea (scan matching +
--  pose graph + loop closure) but a different implementation:
--    * builds small local SUBMAPS and stitches them together
--    * very good loop closure, heavy configuration (this Lua file!)
--    * publishes its map through a second node: cartographer_occupancy_grid_node
--  Adapted from turtlebot3_cartographer/config/turtlebot3_lds_2d.lua.
--  Reference: https://google-cartographer-ros.readthedocs.io
-- ============================================================================
include "map_builder.lua"
include "trajectory_builder.lua"

options = {
  map_builder = MAP_BUILDER,
  trajectory_builder = TRAJECTORY_BUILDER,
  map_frame = "map",
  tracking_frame = "base_footprint",   -- frame whose motion is estimated (IMU frame if an IMU is used)
  published_frame = "odom",            -- cartographer publishes map -> odom (odometry publishes odom -> base)
  odom_frame = "odom",
  provide_odom_frame = false,          -- our odometry_processor already provides odom
  publish_frame_projected_to_2d = true,
  use_odometry = true,                 -- subscribe to /odom
  use_nav_sat = false,
  use_landmarks = false,
  num_laser_scans = 1,                 -- subscribe to /scan
  num_multi_echo_laser_scans = 0,
  num_subdivisions_per_laser_scan = 1,
  num_point_clouds = 0,
  lookup_transform_timeout_sec = 0.2,
  submap_publish_period_sec = 0.3,
  pose_publish_period_sec = 5e-3,
  trajectory_publish_period_sec = 30e-3,
  rangefinder_sampling_ratio = 1.,
  odometry_sampling_ratio = 1.,
  fixed_frame_pose_sampling_ratio = 1.,
  imu_sampling_ratio = 1.,
  landmarks_sampling_ratio = 1.,
}

MAP_BUILDER.use_trajectory_builder_2d = true

TRAJECTORY_BUILDER_2D.min_range = 0.12
TRAJECTORY_BUILDER_2D.max_range = 12.0
TRAJECTORY_BUILDER_2D.missing_data_ray_length = 5.0
TRAJECTORY_BUILDER_2D.use_imu_data = false
TRAJECTORY_BUILDER_2D.use_online_correlative_scan_matching = true
TRAJECTORY_BUILDER_2D.motion_filter.max_angle_radians = math.rad(0.1)

POSE_GRAPH.constraint_builder.min_score = 0.65
POSE_GRAPH.constraint_builder.global_localization_min_score = 0.7

return options
